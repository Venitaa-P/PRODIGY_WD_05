# wheatherApp
A weather application written with JavaScript and I used apis, as well as the structure of promise, fetch, and sync-await.

# How to use :
First, download the files and open them in your system.Type your desired city in the search box and then press enter.

In the cities section, cities with the same name as that city are displayed all over the world.

And in the map section, the map of that city is displayed

![Screenshot (43)](https://user-images.githubusercontent.com/116202175/235373309-c8497e5a-322d-4835-8910-67cd7ce6d140.png)
![Screenshot (45)](https://user-images.githubusercontent.com/116202175/235373312-512d5c0b-f5f1-4b4a-b942-8790c9dff99d.png)
![Screenshot (46)](https://user-images.githubusercontent.com/116202175/235373317-d5220911-f464-4cae-9869-0ee14d38443e.png)
![Screenshot (47)](https://user-images.githubusercontent.com/116202175/235373324-8682332e-04a6-4308-a448-1a50e69a1383.png)

# Live Demo : 
https://www.linkedin.com/posts/masome-spring_javascript-webdesign-frontend-activity-7056904350803091456-MKK4?utm_source=share&utm_medium=member_desktop
